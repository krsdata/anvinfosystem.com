      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="dashboard">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            
          </a>
          
        </li>
		<li class="treeview">
          <a href="AddRecord">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Add Record</span>
            
          </a>
         
        </li>
		<li class="treeview">
          <a href="BorrowList">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Today And Tommorow</span>
            
          </a>
         
        </li>
		<li class="treeview">
          <a href="searchBydate">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Search By Date</span>
            
          </a>
         
        </li>
		<li class="treeview">
          <a href="SearchByLender">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Search By Lender</span>
            
          </a>
         
        </li>
		<li class="treeview">
          <a href="SearchByBrower">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Search By Borrower</span>
            
          </a>
         
        </li>
		<li class="treeview">
          <a href="loginprofile">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Profile</span>
            
          </a>
         
        </li>
        <li class="treeview">
          <a href="backup">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <span>Back Up</span>
            
          </a>
         
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>